I go through how to use GlideAjax and the importance of setting both value and displayValue on a reference field.

Update set containing a Client script and a Script include. Example is used on incident form and when a CI is entered, it does a GlideAjax call.
Then it get in return a JSON with both the value and displayValue of the support group.