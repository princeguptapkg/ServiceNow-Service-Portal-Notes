WD- Language switch.xml is an older Baseline version of the Language switch widget. To be able to use this in a "public" page and get values you need to use this.
The new version in London uses REST API to get the values and that doesn't work witout authentication.
